#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用真实数据训练中考体育成绩预测模型 - 版本2
更灵活的数据处理，允许部分特征缺失
"""

import pandas as pd
import numpy as np
import os
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib
import chardet

def load_high_school_data(data_dir):
    """加载高中学生体质测试数据"""
    print("加载高中学生体质测试数据...")

    # 主要CSV文件
    csv_files = [
        '高中学生体质测试信息_0.csv',
        '高中学生体质测试信息202312220800.csv',
        '高中学生体质测试信息202404200422.csv',
        '高中学生体质测试信息202407130800.csv',
        '高中学生体质测试信息202411141903.csv',
        '高中学生体质测试信息202508010326.csv'
    ]

    all_data = []

    for csv_file in csv_files:
        file_path = os.path.join(data_dir, csv_file)
        if os.path.exists(file_path):
            try:
                print(f"处理文件: {csv_file}")

                # 检测编码
                with open(file_path, 'rb') as f:
                    raw_data = f.read(10000)
                    encoding = chardet.detect(raw_data)['encoding']

                # 读取CSV文件
                df = pd.read_csv(file_path, encoding=encoding)
                print(f"  数据形状: {df.shape}")

                # 标准化列名
                df = standardize_column_names(df)
                all_data.append(df)

            except Exception as e:
                print(f"  处理文件 {csv_file} 时出错: {e}")

    if not all_data:
        raise ValueError("没有成功加载任何数据文件")

    # 合并数据
    combined_data = pd.concat(all_data, ignore_index=True)
    print(f"合并后数据量: {combined_data.shape}")

    return combined_data

def standardize_column_names(df):
    """标准化列名"""
    column_mapping = {}

    for col in df.columns:
        col_str = str(col)
        # 根据列名内容进行映射
        if '坐位体前屈' in col_str or 'zwtqq' in col_str:
            column_mapping[col] = 'sit_and_reach'
        elif '身高' in col_str or 'sg' in col_str:
            column_mapping[col] = 'height'
        elif '性别' in col_str or 'xb' in col_str:
            column_mapping[col] = 'gender'
        elif '1000米' in col_str or 'lm' in col_str:
            column_mapping[col] = 'run_1000m'
        elif '班级' in col_str or 'bj' in col_str:
            column_mapping[col] = 'class'
        elif '立定跳远' in col_str or 'ldty' in col_str:
            column_mapping[col] = 'long_jump'
        elif '学生姓名' in col_str or 'xsxm' in col_str or '姓名' in col_str:
            column_mapping[col] = 'name'
        elif '50米' in col_str or 'mm' in col_str:
            column_mapping[col] = 'run_50m'
        elif '仰卧起坐' in col_str or 'ywqz' in col_str:
            column_mapping[col] = 'sit_ups'
        elif '800米' in col_str or 'mmm' in col_str:
            column_mapping[col] = 'run_800m'
        elif '引体向上' in col_str or 'ytxs' in col_str:
            column_mapping[col] = 'pull_ups'
        elif '肺活量' in col_str or 'fhl' in col_str:
            column_mapping[col] = 'vital_capacity'
        elif '体重' in col_str or 'tz' in col_str:
            column_mapping[col] = 'weight'
        else:
            column_mapping[col] = col

    return df.rename(columns=column_mapping)

def preprocess_data(df):
    """预处理数据"""
    print("\n预处理数据...")

    # 处理性别
    if 'gender' in df.columns:
        print("处理性别列...")
        def convert_gender(value):
            if pd.isna(value):
                return np.nan
            value_str = str(value).strip()
            if value_str in ['男', '��', '1', '1.0', 1, '1']:
                return 1
            elif value_str in ['女', 'Ů', '0', '0.0', 0, '0']:
                return 0
            else:
                return np.nan

        df['gender'] = df['gender'].apply(convert_gender)
        print(f"  男生: {df['gender'].eq(1).sum()}, 女生: {df['gender'].eq(0).sum()}, 缺失: {df['gender'].isna().sum()}")

    # 处理数值型列
    numeric_columns = [
        'sit_and_reach', 'height', 'run_1000m', 'long_jump',
        'run_50m', 'sit_ups', 'run_800m', 'pull_ups',
        'vital_capacity', 'weight'
    ]

    print("处理数值型列...")
    for col in numeric_columns:
        if col in df.columns:
            # 将非数值转换为NaN
            df[col] = pd.to_numeric(df[col], errors='coerce')
            non_null = df[col].notna().sum()
            print(f"  {col}: {non_null}/{len(df)} ({non_null/len(df)*100:.1f}%)")

    return df

def calculate_scores(df):
    """计算中考体育成绩"""
    print("\n计算中考体育成绩...")

    def calculate_row_score(row):
        score = 0

        # 1. 引体向上（男生）/仰卧起坐（女生）
        if 'gender' in row and not pd.isna(row['gender']):
            if row['gender'] == 1:  # 男生
                if 'pull_ups' in row and not pd.isna(row['pull_ups']):
                    pull_ups = row['pull_ups']
                    if pull_ups >= 15: score += 4
                    elif pull_ups >= 12: score += 3
                    elif pull_ups >= 9: score += 2
                    elif pull_ups >= 6: score += 1
            else:  # 女生
                if 'sit_ups' in row and not pd.isna(row['sit_ups']):
                    sit_ups = row['sit_ups']
                    if sit_ups >= 52: score += 4
                    elif sit_ups >= 46: score += 3
                    elif sit_ups >= 40: score += 2
                    elif sit_ups >= 34: score += 1

        # 2. 1000米跑（男生）/800米跑（女生）
        if 'gender' in row and not pd.isna(row['gender']):
            if row['gender'] == 1:  # 男生
                if 'run_1000m' in row and not pd.isna(row['run_1000m']):
                    run_1000m = row['run_1000m']
                    if run_1000m <= 3.37: score += 4
                    elif run_1000m <= 3.47: score += 3
                    elif run_1000m <= 3.57: score += 2
                    elif run_1000m <= 3.67: score += 1
            else:  # 女生
                if 'run_800m' in row and not pd.isna(row['run_800m']):
                    run_800m = row['run_800m']
                    if run_800m <= 3.24: score += 4
                    elif run_800m <= 3.34: score += 3
                    elif run_800m <= 3.44: score += 2
                    elif run_800m <= 3.54: score += 1

        # 3. 50米跑
        if 'run_50m' in row and not pd.isna(row['run_50m']):
            run_50m = row['run_50m']
            if run_50m <= 7.3: score += 4
            elif run_50m <= 7.8: score += 3
            elif run_50m <= 8.3: score += 2
            elif run_50m <= 8.8: score += 1

        # 4. 立定跳远
        if 'long_jump' in row and not pd.isna(row['long_jump']):
            long_jump = row['long_jump']
            if long_jump >= 250: score += 4
            elif long_jump >= 230: score += 3
            elif long_jump >= 210: score += 2
            elif long_jump >= 190: score += 1

        # 5. 坐位体前屈
        if 'sit_and_reach' in row and not pd.isna(row['sit_and_reach']):
            sit_and_reach = row['sit_and_reach']
            if sit_and_reach >= 20: score += 3
            elif sit_and_reach >= 15: score += 2
            elif sit_and_reach >= 10: score += 1

        # 6. 肺活量
        if 'vital_capacity' in row and not pd.isna(row['vital_capacity']):
            vital_capacity = row['vital_capacity']
            if vital_capacity >= 4000: score += 3
            elif vital_capacity >= 3500: score += 2
            elif vital_capacity >= 3000: score += 1

        return min(score, 22)

    df['zhongkao_score'] = df.apply(calculate_row_score, axis=1)

    print("中考成绩分布:")
    score_counts = df['zhongkao_score'].value_counts().sort_index()
    for score, count in score_counts.items():
        print(f"  {score}分: {count}人")

    return df

def prepare_features_with_imputation(df):
    """准备特征数据，使用插值处理缺失值"""
    print("\n准备特征数据...")

    # 基本特征（必须有）
    basic_features = ['gender', 'height', 'weight', 'run_50m', 'long_jump', 'sit_and_reach', 'vital_capacity']

    # 可选特征（可以缺失）
    optional_features = ['pull_ups', 'sit_ups', 'run_1000m', 'run_800m']

    all_features = basic_features + optional_features

    # 检查哪些特征存在
    available_features = [col for col in all_features if col in df.columns]
    print(f"可用特征: {available_features}")

    # 检查数据完整性
    print("\n数据完整性检查:")
    for col in available_features + ['zhongkao_score']:
        non_null = df[col].notna().sum()
        print(f"  {col}: {non_null}/{len(df)} ({non_null/len(df)*100:.1f}%)")

    # 选择有基本特征和成绩的数据
    required_cols = [col for col in basic_features if col in df.columns] + ['zhongkao_score']
    df_clean = df.dropna(subset=required_cols)

    print(f"\n清洗后数据量: {df_clean.shape}")
    print(f"有效样本数: {len(df_clean)}")

    if len(df_clean) < 50:
        print("警告: 数据量较少，可能影响模型训练效果")

    return df_clean, available_features

def train_model_with_imputation(df, feature_columns):
    """训练模型，使用插值处理缺失值"""
    print("\n训练模型...")

    # 准备数据
    X = df[feature_columns].values
    y = df['zhongkao_score'].values

    print(f"特征矩阵形状: {X.shape}")
    print(f"目标向量形状: {y.shape}")

    # 使用中位数插值处理缺失值
    imputer = SimpleImputer(strategy='median')
    X_imputed = imputer.fit_transform(X)

    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(
        X_imputed, y, test_size=0.2, random_state=42
    )

    print(f"训练集大小: {X_train.shape}")
    print(f"测试集大小: {X_test.shape}")

    # 标准化特征
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # 训练随机森林模型
    print("\n训练随机森林模型...")
    model = RandomForestRegressor(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        n_jobs=-1
    )

    model.fit(X_train_scaled, y_train)

    # 评估模型
    y_pred = model.predict(X_test_scaled)

    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)

    print(f"\n模型性能评估:")
    print(f"平均绝对误差 (MAE): {mae:.4f}")
    print(f"均方误差 (MSE): {mse:.4f}")
    print(f"均方根误差 (RMSE): {rmse:.4f}")
    print(f"决定系数 (R²): {r2:.4f}")

    # 特征重要性
    feature_importance = pd.DataFrame({
        'feature': feature_columns,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)

    print(f"\n特征重要性:")
    print(feature_importance)

    # 显示预测示例
    print("\n预测示例:")
    for i in range(min(5, len(y_test))):
        print(f"真实值: {y_test[i]:.1f}, 预测值: {y_pred[i]:.1f}, 误差: {abs(y_test[i]-y_pred[i]):.2f}")

    return model, scaler, imputer, feature_columns

def save_model(model, scaler, imputer, feature_columns):
    """保存模型"""
    print("\n保存模型...")

    # 保存模型
    joblib.dump(model, '中考体育预测模型_real_v2.pkl')
    joblib.dump(scaler, 'scaler_real_v2.pkl')
    joblib.dump(imputer, 'imputer_real_v2.pkl')

    # 保存特征信息
    import json
    model_info = {
        'feature_columns': feature_columns,
        'model_type': 'RandomForestRegressor',
        'max_score': 22,
        'is_demo': False,
        'data_source': '真实高中学生体质测试数据',
        'version': '2.0',
        'feature_descriptions': {
            'gender': '性别（男=1，女=0）',
            'height': '身高（厘米）',
            'weight': '体重（公斤）',
            'run_50m': '50米跑成绩（秒）',
            'long_jump': '立定跳远成绩（厘米）',
            'sit_and_reach': '坐位体前屈成绩（厘米）',
            'vital_capacity': '肺活量（毫升）',
            'pull_ups': '引体向上次数（男生）',
            'sit_ups': '仰卧起坐次数（女生，次/分钟）',
            'run_1000m': '1000米跑成绩（分钟，男生）',
            'run_800m': '800米跑成绩（分钟，女生）'
        }
    }

    with open('model_info_real_v2.json', 'w', encoding='utf-8') as f:
        json.dump(model_info, f, ensure_ascii=False, indent=2)

    print("模型保存完成!")

def create_prediction_interface():
    """创建预测接口"""
    print("\n创建预测接口...")

    interface_code = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基于真实数据的中考体育成绩预测系统 - 版本2
使用真实高中学生体质测试数据训练的模型
支持部分特征缺失
"""

import joblib
import numpy as np
import json

def load_model():
    """加载模型"""
    # 加载模型信息
    with open('model_info_real_v2.json', 'r', encoding='utf-8') as f:
        model_info = json.load(f)

    # 加载模型、标准化器和插值器
    model = joblib.load('中考体育预测模型_real_v2.pkl')
    scaler = joblib.load('scaler_real_v2.pkl')
    imputer = joblib.load('imputer_real_v2.pkl')

    print("基于真实数据训练的模型已加载")
    print(f"版本: {model_info.get('version', '2.0')}")
    print(f"数据来源: {model_info.get('data_source', '真实高中学生体质测试数据')}")

    return model, scaler, imputer, model_info

def predict_score(input_data, model_info):
    """预测中考体育成绩"""
    model, scaler, imputer, _ = load_model()
    feature_columns = model_info['feature_columns']

    # 准备输入数据
    input_array = []
    for col in feature_columns:
        if col in input_data:
            input_array.append(input_data[col])
        else:
            input_array.append(0)  # 缺失特征用0填充

    input_array = np.array(input_array, dtype='float32').reshape(1, -1)

    # 使用训练时的插值器处理缺失值
    input_imputed = imputer.transform(input_array)

    # 标准化
    input_scaled = scaler.transform(input_imputed)

    # 预测
    prediction = model.predict(input_scaled)[0]

    # 确保预测值在合理范围内
    prediction = max(0, min(prediction, 22))

    return round(prediction, 1)

def main():
    """主函数"""
    print("=" * 70)
    print("基于真实数据的中考体育成绩预测系统 - 版本2")
    print("=" * 70)
    print("说明: 使用真实高中学生体质测试数据训练的模型")
    print("      支持部分特征缺失，提供更准确的预测")
    print()

    # 加载模型信息
    with open('model_info_real_v2.json', 'r', encoding='utf-8') as f:
        model_info = json.load(f)

    feature_columns = model_info['feature_columns']
    feature_descriptions = model_info.get('feature_descriptions', {})

    print("请输入以下测试项目的成绩：")
    print("（如果某项没有测试成绩，请输入0）")
    print("-" * 60)

    input_data = {}
    for feature in feature_columns:
        desc = feature_descriptions.get(feature, feature)

        if feature == 'gender':
            print(f"{desc}:")
            print("  1 - 男生")
            print("  0 - 女生")
            gender_input = input("请选择性别 (1/0): ").strip()
            try:
                input_data[feature] = 1 if gender_input == '1' else 0
            except:
                input_data[feature] = 0
            continue

        # 提供输入提示
        if feature == 'run_1000m':
            print(f"{desc}（例如: 3.5表示3分30秒）")
        elif feature == 'run_800m':
            print(f"{desc}（例如: 3.2表示3分12秒）")
        elif feature == 'run_50m':
            print(f"{desc}（例如: 7.5表示7.5秒）")
        elif feature == 'long_jump':
            print(f"{desc}（单位: 厘米）")
        elif feature == 'sit_and_reach':
            print(f"{desc}（单位: 厘米）")
        elif feature == 'vital_capacity':
            print(f"{desc}（单位: 毫升）")
        elif feature == 'height':
            print(f"{desc}（单位: 厘米）")
        elif feature == 'weight':
            print(f"{desc}（单位: 公斤）")
        elif feature == 'pull_ups':
            print(f"{desc}（男生项目，女生请填0）")
        elif feature == 'sit_ups':
            print(f"{desc}（女生项目，男生请填0）")

        value = input(f"{desc}: ").strip()
        try:
            input_data[feature] = float(value) if value else 0
        except:
            print(f"警告: '{value}' 不是有效数字，使用默认值0")
            input_data[feature] = 0

    print()
    print("正在计算预测成绩...")

    try:
        score = predict_score(input_data, model_info)
        print(f"预测中考体育成绩: {score}分 (满分22分)")
        print()

        # 成绩等级评估
        if score >= 20:
            print("成绩等级: 🏆 优秀")
            print("评价: 体育成绩非常出色，继续保持！")
        elif score >= 16:
            print("成绩等级: 👍 良好")
            print("评价: 体育成绩良好，有提升空间")
        elif score >= 12:
            print("成绩等级: ✅ 及格")
            print("评价: 达到及格标准，需要加强训练")
        else:
            print("成绩等级: ⚠️ 待提高")
            print("评价: 需要加强体育锻炼，重点关注薄弱项目")

        print()
        print("💡 训练建议:")
        print("1. 根据预测结果，针对薄弱项目进行专项训练")
        print("2. 制定科学的训练计划，循序渐进")
        print("3. 注意训练安全，避免受伤")
        print("4. 定期测试，跟踪进步情况")

    except Exception as e:
        print(f"预测出错: {e}")

if __name__ == "__main__":
    main()'''

    with open('predict_zhongkao_real_v2.py', 'w', encoding='utf-8') as f:
        f.write(interface_code)

    print("预测接口已保存到 predict_zhongkao_real_v2.py")

def main():
    """主函数"""
    print("=" * 80)
    print("基于真实数据的中考体育成绩预测模型训练 - 版本2")
    print("=" * 80)
    print("使用真实高中学生体质测试数据训练模型")
    print("支持部分特征缺失，使用插值处理")
    print()

    data_dir = "."

    try:
        # 1. 加载数据
        print("1. 加载数据...")
        raw_data = load_high_school_data(data_dir)

        # 2. 预处理数据
        print("\n2. 预处理数据...")
        cleaned_data = preprocess_data(raw_data)

        # 3. 计算中考成绩
        print("\n3. 计算中考成绩...")
        data_with_scores = calculate_scores(cleaned_data)

        # 4. 准备特征数据
        print("\n4. 准备特征数据...")
        training_data, feature_columns = prepare_features_with_imputation(data_with_scores)

        if len(training_data) < 10:
            print("数据量不足，无法训练模型")
            return

        # 5. 训练模型
        print("\n5. 训练模型...")
        model, scaler, imputer, feature_columns = train_model_with_imputation(training_data, feature_columns)

        # 6. 保存模型
        print("\n6. 保存模型...")
        save_model(model, scaler, imputer, feature_columns)

        # 7. 创建预测接口
        print("\n7. 创建预测接口...")
        create_prediction_interface()

        print("\n" + "=" * 80)
        print("基于真实数据的模型训练完成!")
        print("=" * 80)
        print()
        print("📊 训练结果总结:")
        print(f"- 使用数据量: {len(training_data)} 个样本")
        print(f"- 特征数量: {len(feature_columns)} 个")
        print(f"- 支持部分特征缺失")
        print()
        print("🚀 使用方法:")
        print("1. 运行预测程序: python predict_zhongkao_real_v2.py")
        print("2. 按照提示输入各项测试成绩")
        print("3. 系统将基于真实数据模型预测中考体育成绩")
        print()
        print("💡 模型特点:")
        print("- 基于真实高中学生体质测试数据训练")
        print("- 支持部分特征缺失，使用插值处理")
        print("- 考虑了性别差异和不同项目的评分标准")

    except Exception as e:
        print(f"\n错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()