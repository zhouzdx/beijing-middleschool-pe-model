@echo off
chcp 65001 > nul
echo.
echo ============================================
echo   北京中考体育成绩预测系统
echo ============================================
echo.
echo 系统功能：根据体质测试成绩预测中考体育分数
echo 满分：22分
echo.
echo 正在启动预测系统...
echo.

REM 检查Python是否安装
python --version > nul 2>&1
if errorlevel 1 (
    echo 错误：未检测到Python，请先安装Python 3.7+
    echo 下载地址：https://www.python.org/downloads/
    pause
    exit /b 1
)

REM 检查必要库是否安装
echo 检查必要库...
python -c "import pandas, numpy, sklearn, joblib" > nul 2>&1
if errorlevel 1 (
    echo 正在安装必要库...
    pip install pandas numpy scikit-learn joblib
    if errorlevel 1 (
        echo 错误：库安装失败，请手动安装
        echo 命令：pip install pandas numpy scikit-learn joblib
        pause
        exit /b 1
    )
)

REM 运行预测系统
echo.
echo 请选择预测模型版本：
echo 1. 基于真实数据的模型 (推荐)
echo 2. 演示模型 (基于模拟数据)
echo.
set /p choice="请选择 (1或2): "

if "%choice%"=="1" (
    echo.
    echo 启动基于真实数据的预测系统...
    echo.
    python predict_zhongkao_real_v2.py
) else (
    echo.
    echo 启动演示预测系统...
    echo.
    python predict_zhongkao_score.py
)

echo.
echo ============================================
echo   预测完成！
echo ============================================
echo.
echo 其他功能：
echo 1. 创建数据收集模板：python create_data_template.py
echo 2. 测试模型：python 测试预测模型.py
echo 3. 查看使用指南：type 使用指南.txt
echo.
pause