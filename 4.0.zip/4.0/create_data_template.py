#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中考体育成绩数据收集模板
用于收集真实的学生体质测试数据和中考体育成绩
"""

import pandas as pd
import os

def create_data_template():
    """创建数据收集模板"""
    # 定义数据列
    columns = [
        'student_id',      # 学生ID
        'name',           # 姓名
        'gender',         # 性别（男=1，女=0）
        'age',            # 年龄
        'height',         # 身高（厘米）
        'weight',         # 体重（公斤）

        # 中考体育测试项目
        'pull_ups',       # 引体向上（男生，次数）
        'sit_ups',        # 仰卧起坐（女生，次/分钟）
        'run_1000m',      # 1000米跑（男生，分钟）
        'run_800m',       # 800米跑（女生，分钟）
        'run_50m',        # 50米跑（秒）
        'long_jump',      # 立定跳远（厘米）
        'sit_and_reach',  # 坐位体前屈（厘米）
        'vital_capacity', # 肺活量（毫升）

        # 中考实际成绩
        'zhongkao_score'  # 中考体育成绩（满分22分）
    ]

    # 创建空的DataFrame
    df = pd.DataFrame(columns=columns)

    # 保存模板
    template_file = '中考体育数据收集模板.csv'
    df.to_csv(template_file, index=False, encoding='utf-8-sig')

    print(f"数据收集模板已创建: {template_file}")
    print()
    print("使用说明:")
    print("1. 使用Excel或文本编辑器打开模板文件")
    print("2. 填写学生的体质测试数据和中考体育成绩")
    print("3. 保存文件后，可以用于训练更准确的预测模型")
    print()
    print("数据填写注意事项:")
    print("- 性别: 男生填1，女生填0")
    print("- 时间单位: 1000米/800米用分钟表示（如3.5表示3分30秒）")
    print("- 距离单位: 厘米")
    print("- 次数: 整数")
    print("- 中考成绩: 0-22之间的整数")

def main():
    print("=" * 60)
    print("中考体育成绩数据收集模板生成器")
    print("=" * 60)

    create_data_template()

if __name__ == "__main__":
    main()