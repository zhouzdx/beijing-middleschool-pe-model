#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基于真实数据的中考体育成绩预测系统 - 版本2
使用真实高中学生体质测试数据训练的模型
支持部分特征缺失
"""

import joblib
import numpy as np
import json

def load_model():
    """加载模型"""
    # 加载模型信息
    with open('model_info_real_v2.json', 'r', encoding='utf-8') as f:
        model_info = json.load(f)

    # 加载模型、标准化器和插值器
    model = joblib.load('中考体育预测模型_real_v2.pkl')
    scaler = joblib.load('scaler_real_v2.pkl')
    imputer = joblib.load('imputer_real_v2.pkl')

    print("基于真实数据训练的模型已加载")
    print(f"版本: {model_info.get('version', '2.0')}")
    print(f"数据来源: {model_info.get('data_source', '真实高中学生体质测试数据')}")

    return model, scaler, imputer, model_info

def predict_score(input_data, model_info):
    """预测中考体育成绩"""
    model, scaler, imputer, _ = load_model()
    feature_columns = model_info['feature_columns']

    # 准备输入数据
    input_array = []
    for col in feature_columns:
        if col in input_data:
            input_array.append(input_data[col])
        else:
            input_array.append(0)  # 缺失特征用0填充

    input_array = np.array(input_array, dtype='float32').reshape(1, -1)

    # 使用训练时的插值器处理缺失值
    input_imputed = imputer.transform(input_array)

    # 标准化
    input_scaled = scaler.transform(input_imputed)

    # 预测
    prediction = model.predict(input_scaled)[0]

    # 确保预测值在合理范围内
    prediction = max(0, min(prediction, 22))

    return round(prediction, 1)

def main():
    """主函数"""
    print("=" * 70)
    print("基于真实数据的中考体育成绩预测系统 - 版本2")
    print("=" * 70)
    print("说明: 使用真实高中学生体质测试数据训练的模型")
    print("      支持部分特征缺失，提供更准确的预测")
    print()

    # 加载模型信息
    with open('model_info_real_v2.json', 'r', encoding='utf-8') as f:
        model_info = json.load(f)

    feature_columns = model_info['feature_columns']
    feature_descriptions = model_info.get('feature_descriptions', {})

    print("请输入以下测试项目的成绩：")
    print("（如果某项没有测试成绩，请输入0）")
    print("-" * 60)

    input_data = {}
    for feature in feature_columns:
        desc = feature_descriptions.get(feature, feature)

        if feature == 'gender':
            print(f"{desc}:")
            print("  1 - 男生")
            print("  0 - 女生")
            gender_input = input("请选择性别 (1/0): ").strip()
            try:
                input_data[feature] = 1 if gender_input == '1' else 0
            except:
                input_data[feature] = 0
            continue

        # 提供输入提示
        if feature == 'run_1000m':
            print(f"{desc}（例如: 3.5表示3分30秒）")
        elif feature == 'run_800m':
            print(f"{desc}（例如: 3.2表示3分12秒）")
        elif feature == 'run_50m':
            print(f"{desc}（例如: 7.5表示7.5秒）")
        elif feature == 'long_jump':
            print(f"{desc}（单位: 厘米）")
        elif feature == 'sit_and_reach':
            print(f"{desc}（单位: 厘米）")
        elif feature == 'vital_capacity':
            print(f"{desc}（单位: 毫升）")
        elif feature == 'height':
            print(f"{desc}（单位: 厘米）")
        elif feature == 'weight':
            print(f"{desc}（单位: 公斤）")
        elif feature == 'pull_ups':
            print(f"{desc}（男生项目，女生请填0）")
        elif feature == 'sit_ups':
            print(f"{desc}（女生项目，男生请填0）")

        value = input(f"{desc}: ").strip()
        try:
            input_data[feature] = float(value) if value else 0
        except:
            print(f"警告: '{value}' 不是有效数字，使用默认值0")
            input_data[feature] = 0

    print()
    print("正在计算预测成绩...")

    try:
        score = predict_score(input_data, model_info)
        print(f"预测中考体育成绩: {score}分 (满分22分)")
        print()

        # 成绩等级评估
        if score >= 20:
            print("成绩等级: 🏆 优秀")
            print("评价: 体育成绩非常出色，继续保持！")
        elif score >= 16:
            print("成绩等级: 👍 良好")
            print("评价: 体育成绩良好，有提升空间")
        elif score >= 12:
            print("成绩等级: ✅ 及格")
            print("评价: 达到及格标准，需要加强训练")
        else:
            print("成绩等级: ⚠️ 待提高")
            print("评价: 需要加强体育锻炼，重点关注薄弱项目")

        print()
        print("💡 训练建议:")
        print("1. 根据预测结果，针对薄弱项目进行专项训练")
        print("2. 制定科学的训练计划，循序渐进")
        print("3. 注意训练安全，避免受伤")
        print("4. 定期测试，跟踪进步情况")

    except Exception as e:
        print(f"预测出错: {e}")

if __name__ == "__main__":
    main()