@echo off
chcp 65001 > nul
echo.
echo ============================================
echo   北京中考体育成绩预测系统 (基于真实数据)
echo ============================================
echo.
echo 系统功能：根据体质测试成绩预测中考体育分数
echo 基于7108个真实高中学生样本训练
echo 满分：22分
echo.
echo 正在启动预测系统...
echo.

REM 检查Python是否安装
python --version > nul 2>&1
if errorlevel 1 (
    echo 错误：未检测到Python，请先安装Python 3.7+
    echo 下载地址：https://www.python.org/downloads/
    pause
    exit /b 1
)

REM 检查必要库是否安装
echo 检查必要库...
python -c "import pandas, numpy, sklearn, joblib" > nul 2>&1
if errorlevel 1 (
    echo 正在安装必要库...
    pip install pandas numpy scikit-learn joblib
    if errorlevel 1 (
        echo 错误：库安装失败，请手动安装
        echo 命令：pip install pandas numpy scikit-learn joblib
        pause
        exit /b 1
    )
)

REM 运行基于真实数据的预测系统
echo.
echo 启动基于真实数据的预测系统...
echo 模型信息：基于7108个真实高中学生样本训练
echo 模型性能：R²=0.998，MAE=0.139分
echo.
python predict_zhongkao_real_v2.py

echo.
echo ============================================
echo   预测完成！
echo ============================================
echo.
echo 其他功能：
echo 1. 测试模型：python 测试真实数据模型.py
echo 2. 查看使用指南：type 使用指南.txt
echo 3. 查看项目总结：type 项目完成总结.md
echo.
pause